// src/app/api/hello/route.js
export async function GET(req) {
  return Response.json({ message: "Hello from test API 🚀" })
}
